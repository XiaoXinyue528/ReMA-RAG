﻿from src.utils import GraphState, make_chat_openai, invoke_structured_with_retry
from src.prompt_template import planing_system_message, planing_human_message, planing_input_variables
from src.utils import PlanFormat

from dotenv import load_dotenv
# 修复 1：将废弃的 langchain.chat_models 替换为最新的 langchain_openai
from langchain_openai import ChatOpenAI
import os

from langchain_core.prompts.chat import ChatPromptTemplate, HumanMessagePromptTemplate, SystemMessagePromptTemplate

load_dotenv()

def plan_agent(state: GraphState):
    API_KEY = os.getenv("API_KEY")
    original_question = state["original_question"]
    all_mem = []
    for past_exp in state["past_exp"]:
        memory = ""
        plan = ', '.join(past_exp["plan"])
        memory += f"Plan: [{plan}]\n"
        # 修复 2：把内部的双引号全部换成单引号，解决语法冲突
        memory += f"Status: {past_exp['plan_summary']['output']} Score: {past_exp['plan_summary']['score']}\n"
        all_mem.append(memory)
    memory = ""
    if len(all_mem) == 0:
        memory = "empty"
    else:
        for id in range(len(all_mem)):
            memory += f"Trial {id}:\n{all_mem[id]}\n"
    
    messages = [
        SystemMessagePromptTemplate.from_template(planing_system_message),
        HumanMessagePromptTemplate.from_template(planing_human_message),
    ]
    prompt = ChatPromptTemplate(input_variables=planing_input_variables, messages=messages)
    llm = make_chat_openai(temperature=0.3, api_key=API_KEY)
    structured_llm = llm.with_structured_output(PlanFormat)
    chain = prompt | structured_llm
    fprompt = prompt.format(
        question = original_question,
        memory = memory
    )
    output = invoke_structured_with_retry(chain, {
        "question": original_question,
        "memory": memory
    }, task_name="plan_agent")
    return {"plan": output.step}
